# -*- coding: utf-8 -*-
import cv2
import kornia
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision


def imshow(input: torch.Tensor):
    out = torchvision.utils.make_grid(input, nrow=2, padding=5)
    out_np = kornia.tensor_to_image(out)
    plt.imshow(out_np)
    plt.axis('off')
    plt.show()


def main():
    # Load image with OpenCV, cast to 4D tensor, and  convert from BGR to RGB
    img_bgr = cv2.imread('./data/raw/NA_Fish_Dataset/Trout/00009.png',
                         cv2.IMREAD_COLOR)  # HxWxC / np.uint8
    print(img_bgr.shape)
    x_bgr = kornia.image_to_tensor(img_bgr)  # 1xCxHxW / torch.uint8
    x_rgb = kornia.color.bgr_to_rgb(x_bgr)  # 1xCxHxW / torch.uint8
    print(x_rgb.shape)

    # OR: Load an image with Torchvision
    x_rgb = torchvision.io.read_image('./data/raw/NA_Fish_Dataset/Trout/00009.png')  # CxHxW / torch.uint8
    print(x_rgb.shape)
    x_rgb = x_rgb.unsqueeze(0)  # BxCxHxW   
    print(x_rgb.shape)

    img_rgb = kornia.tensor_to_image(x_rgb.byte())  # HxWxC / np.uint8

    fig, axs = plt.subplots(1, 2, figsize=(32, 16))
    axs = axs.ravel()
    axs[0].axis('off')
    axs[0].imshow(img_rgb)
    axs[1].axis('off')
    axs[1].imshow(img_bgr)
    #plt.show()

    # Perform hflip, vflip, and rotation and plot the batchs 
    x_rgb = torchvision.io.read_image('./data/raw/NA_Fish_Dataset/Trout/00009.png')  # CxHxW / torch.uint8
    print(x_rgb.shape)
    print(kornia.hflip(x_rgb).shape)
    print(kornia.vflip(x_rgb).shape)
    print(kornia.rot180(x_rgb).shape)
    xb_rgb = torch.stack([x_rgb, kornia.hflip(x_rgb),
                         kornia.vflip(x_rgb), kornia.rot180(x_rgb)])
    print(xb_rgb.shape)
    imshow(xb_rgb)

    k2 = kornia.augmentation.ColorJitter(0.15, 0.25, 0.25, 0.25)
    #blur = kornia.filters.BoxBlur((3,3))
    #test = kornia.filters.unsharp_mask(x_rgb.unsqueeze(0), (3, 3), (1.5, 1.5))
    #breakpoint()
    
    
    test = k2(kornia.normalize(x_rgb.unsqueeze(0), 0., 255.))
    out_np = kornia.tensor_to_image(test)
    plt.imshow(out_np)
    plt.show()


if __name__ == '__main__':

    main()

