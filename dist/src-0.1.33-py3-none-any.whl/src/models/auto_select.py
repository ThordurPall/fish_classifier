import os.path
import glob


def main():
    folder_path = "./dist"
    file_type = "/*"
    files = glob.glob(folder_path + file_type)

    max_file = max(files, key=os.path.getctime)

    print(str(max_file))


if __name__ == "__main__":
    main()
