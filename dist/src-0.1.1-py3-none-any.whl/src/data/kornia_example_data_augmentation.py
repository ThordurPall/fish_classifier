# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import cv2

import torch
import kornia as K
import src.data.MyAugmentation

def load_data(data_path: str):
    data = cv2.imread(data_path, cv2.IMREAD_COLOR)
    data_t = K.image_to_tensor(data, keepdim=False)
    data_t = K.bgr_to_rgb(data_t)
    img = K.normalize(data_t, 0., 255.)
    return img
 
def main():
    # load data (B, C, H, W)
    img = load_data("./data/raw/NA_Fish_Dataset/Horse Mackerel/00001.png")

    # create augmentation instance
    aug = src.data.MyAugmentation.MyAugmentation()

    # apply the augmenation pipeline to our batch of data
    img_aug = aug(img)

    # visualize
    #img_out = torch.cat([img, labels], dim=-1)
    plt.imshow(K.tensor_to_image(img_aug))
    plt.axis('off')
    plt.show()
    
    # generate several samples
    num_samples: int = 5

    for img_id in range(num_samples):
        # generate data
        img_aug = aug(img)

        # Plot data
        plt.figure()
        plt.imshow(K.tensor_to_image(img_aug))
        plt.axis('off')
        plt.show()


if __name__ == '__main__':

    main()

